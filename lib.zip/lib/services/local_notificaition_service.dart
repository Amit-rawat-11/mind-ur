import 'dart:math';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;

class LocalNotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  // Notification IDs (fixed)
  static const int morningId = 100;
  static const int afternoonId = 110;
  static const int eveningId = 120;
  static const int nightId = 130;
  static const int goodNightId = 140;

  static Future<void> init() async {
    tzdata.initializeTimeZones();

    const androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const initSettings = InitializationSettings(android: androidInit);

    await _plugin.initialize(initSettings);

    // Android 13+
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  // ---------- CORE HELPERS ----------

  static NotificationDetails _details(String channelId, String name) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        name,
        importance: Importance.high,
        priority: Priority.high,
      ),
    );
  }

  static tz.TZDateTime _todayAt(int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var time =
        tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (time.isBefore(now)) {
      time = time.add(const Duration(days: 1));
    }
    return time;
  }

  static Future<void> _schedule(
    int id,
    int hour,
    int minute,
    String title,
    String body,
    String channelId,
  ) async {
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      _todayAt(hour, minute),
      _details(channelId, channelId),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> cancel(int id) async {
    await _plugin.cancel(id);
  }

  // ---------- PUBLIC API ----------

  static Future<void> scheduleMorning(int hour, int minute) async {
    await _schedule(
      morningId,
      hour,
      minute,
      "Today's Goals",
      "Your habits are waiting for you",
      "morning",
    );
  }

  static Future<void> scheduleAfternoon(
      int hour, int minute, int remaining) async {
    await _schedule(
      afternoonId,
      hour,
      minute,
      "Progress Check",
      "$remaining habits still left today",
      "afternoon",
    );
  }

  static Future<void> scheduleEvening(int hour, int minute) async {
    await _schedule(
      eveningId,
      hour,
      minute,
      "Final Push",
      "Finish strong today 💪",
      "evening",
    );
  }

  static Future<void> scheduleNight(int hour, int minute) async {
    await _schedule(
      nightId,
      hour,
      minute,
      "Day Ending",
      "Some habits are still pending",
      "night",
    );
  }

  static Future<void> scheduleGoodNight(int hour, int minute) async {
    final messages = [
      "Today's work is complete. Sleep peacefully 😴",
      "Great job today. You earned your rest",
      "All habits done. Proud of you"
    ];

    await _schedule(
      goodNightId,
      hour,
      minute,
      "Well Done",
      messages[Random().nextInt(messages.length)],
      "goodnight",
    );
  }
}
